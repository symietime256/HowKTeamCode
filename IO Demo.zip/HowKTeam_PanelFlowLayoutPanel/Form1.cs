namespace HowKTeam_PanelFlowLayoutPanel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            Button b1 = new Button();
            b1.Text = "OK";
            b1.AutoSize = true;



            b1.Location = new Point(rand.Next(0, panel1.Size.Width), rand.Next(0, panel1.Size.Height));
            panel1.Controls.Add(b1);
            flowLayoutPanel1.Controls.Add(b1); // chi chen dc 1 thang, thang nao dung saau thi an dc
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Enabled = !panel1.Enabled;
        }
    }
}