﻿namespace HowKTeam_TextBox
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            lbl2 = new Label();
            txtBox2 = new TextBox();
            btn1 = new Button();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(38, 84);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ScrollBars = ScrollBars.Vertical;
            textBox1.Size = new Size(116, 74);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(184, 84);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(165, 23);
            textBox2.TabIndex = 1;
            textBox2.Text = "DucMinh2001";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(195, 110);
            label1.Name = "label1";
            label1.Size = new Size(134, 36);
            label1.TabIndex = 2;
            label1.Text = "Click here!";
            // 
            // lbl2
            // 
            lbl2.AutoSize = true;
            lbl2.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            lbl2.Location = new Point(76, 354);
            lbl2.Name = "lbl2";
            lbl2.Size = new Size(63, 25);
            lbl2.TabIndex = 3;
            lbl2.Text = "label2";
            // 
            // txtBox2
            // 
            txtBox2.Location = new Point(38, 317);
            txtBox2.Name = "txtBox2";
            txtBox2.Size = new Size(156, 23);
            txtBox2.TabIndex = 4;
            txtBox2.TextChanged += txtBox2_TextChanged;
            // 
            // btn1
            // 
            btn1.Location = new Point(215, 317);
            btn1.Name = "btn1";
            btn1.Size = new Size(75, 23);
            btn1.TabIndex = 5;
            btn1.Text = "Click Here";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // Form1
            // 
            AcceptButton = btn1;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(521, 431);
            Controls.Add(btn1);
            Controls.Add(txtBox2);
            Controls.Add(lbl2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label lbl2;
        private TextBox txtBox2;
        private Button btn1;
    }
}