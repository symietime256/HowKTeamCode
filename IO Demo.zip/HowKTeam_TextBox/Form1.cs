namespace HowKTeam_TextBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            // lbl2.Text = txtBox2.Text;
            // AcceptButton : button1, enter ph�t la ngon
            // CancelButton : button1, escape la ra 

            int num = 0;

            if (Int32.TryParse(txtBox2.Text, out num))
            {
                lbl2.Text = (num + num).ToString();

            }
            else
            {
                Console.WriteLine("Vui long nhap so");
            }
        }

        private void txtBox2_TextChanged(object sender, EventArgs e)
        {
            int num = 0;

            if (Int32.TryParse(txtBox2.Text, out num))
            {
                lbl2.Text = (num * num).ToString();

            }
            else
            {
                Console.WriteLine("Vui long nhap so");
            }
        }
    }
}