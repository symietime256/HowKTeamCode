namespace HowKTeam_MessageBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("haha"); // Exclamation - tieng
            DialogResult dr = MessageBox.Show("noi dung", "haha thu 2", MessageBoxButtons.YesNoCancel, 
                MessageBoxIcon.Hand, MessageBoxDefaultButton.Button2, MessageBoxOptions.ServiceNotification);

            switch (dr)
            {

                case DialogResult.Abort:
                    break;
                case DialogResult.OK:
                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Dong messagebox ne` :");
                    break;
                case DialogResult.Ignore:
                    break;
                case DialogResult.No:
                    MessageBox.Show("Cai moi cua no :");
                    break;
                case DialogResult.Yes:
                    MessageBox.Show("Cai moi cua yes :");
                    break;
                case DialogResult.Retry:
                    break;
                case DialogResult.None:
                    break;
                
                default:
                    break;
            }
        }
    }
}