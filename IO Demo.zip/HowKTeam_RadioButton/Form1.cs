namespace HowKTeam_RadioButton
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void ShowResult(Label a, Panel pn)
        {
            RadioButton ckb = null;

            foreach (RadioButton c in pn.Controls)
            {
                if (c!=null) 
                {
                    if (c.Checked) ckb = c;
                    break;
                }
            }

            if (ckb != null)
            {
                a.Text = ckb.Text;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ShowResult(label1, panel11);
            ShowResult(label2, panel12);
            ShowResult(label3, panel13);
        }
    }
}