﻿namespace HowKTeam_RadioButton
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            panel12 = new Panel();
            panel11 = new Panel();
            radioButton5 = new RadioButton();
            radioButton6 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton8 = new RadioButton();
            panel13 = new Panel();
            radioButton9 = new RadioButton();
            radioButton10 = new RadioButton();
            radioButton11 = new RadioButton();
            radioButton12 = new RadioButton();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            panel12.SuspendLayout();
            panel11.SuspendLayout();
            panel13.SuspendLayout();
            SuspendLayout();
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton1.Location = new Point(24, 45);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(144, 32);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "caia gi dday?";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton2.Location = new Point(24, 83);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(144, 32);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "caia gi dday?";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton3.Location = new Point(24, 121);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(144, 32);
            radioButton3.TabIndex = 2;
            radioButton3.TabStop = true;
            radioButton3.Text = "caia gi dday?";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton4.Location = new Point(24, 159);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(144, 32);
            radioButton4.TabIndex = 3;
            radioButton4.TabStop = true;
            radioButton4.Text = "caia gi dday?";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            panel12.Controls.Add(radioButton1);
            panel12.Controls.Add(radioButton4);
            panel12.Controls.Add(radioButton2);
            panel12.Controls.Add(radioButton3);
            panel12.Location = new Point(315, 85);
            panel12.Name = "panel12";
            panel12.Size = new Size(206, 254);
            panel12.TabIndex = 4;
            // 
            // panel11
            // 
            panel11.Controls.Add(radioButton5);
            panel11.Controls.Add(radioButton6);
            panel11.Controls.Add(radioButton7);
            panel11.Controls.Add(radioButton8);
            panel11.Location = new Point(75, 85);
            panel11.Name = "panel11";
            panel11.Size = new Size(206, 254);
            panel11.TabIndex = 5;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton5.Location = new Point(24, 45);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(144, 32);
            radioButton5.TabIndex = 0;
            radioButton5.TabStop = true;
            radioButton5.Text = "caia gi dday?";
            radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton6.Location = new Point(24, 83);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(144, 32);
            radioButton6.TabIndex = 3;
            radioButton6.TabStop = true;
            radioButton6.Text = "caia gi dday?";
            radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton7.Location = new Point(24, 121);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(144, 32);
            radioButton7.TabIndex = 1;
            radioButton7.TabStop = true;
            radioButton7.Text = "caia gi dday?";
            radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton8.Location = new Point(24, 159);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(144, 32);
            radioButton8.TabIndex = 2;
            radioButton8.TabStop = true;
            radioButton8.Text = "caia gi dday?";
            radioButton8.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            panel13.Controls.Add(radioButton9);
            panel13.Controls.Add(radioButton10);
            panel13.Controls.Add(radioButton11);
            panel13.Controls.Add(radioButton12);
            panel13.Location = new Point(560, 85);
            panel13.Name = "panel13";
            panel13.Size = new Size(206, 254);
            panel13.TabIndex = 5;
            // 
            // radioButton9
            // 
            radioButton9.AutoSize = true;
            radioButton9.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton9.Location = new Point(24, 45);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(144, 32);
            radioButton9.TabIndex = 0;
            radioButton9.TabStop = true;
            radioButton9.Text = "caia gi dday?";
            radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            radioButton10.AutoSize = true;
            radioButton10.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton10.Location = new Point(24, 83);
            radioButton10.Name = "radioButton10";
            radioButton10.Size = new Size(144, 32);
            radioButton10.TabIndex = 3;
            radioButton10.TabStop = true;
            radioButton10.Text = "caia gi dday?";
            radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            radioButton11.AutoSize = true;
            radioButton11.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton11.Location = new Point(24, 121);
            radioButton11.Name = "radioButton11";
            radioButton11.Size = new Size(144, 32);
            radioButton11.TabIndex = 1;
            radioButton11.TabStop = true;
            radioButton11.Text = "caia gi dday?";
            radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            radioButton12.AutoSize = true;
            radioButton12.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton12.Location = new Point(24, 159);
            radioButton12.Name = "radioButton12";
            radioButton12.Size = new Size(144, 32);
            radioButton12.TabIndex = 2;
            radioButton12.TabStop = true;
            radioButton12.Text = "caia gi dday?";
            radioButton12.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(337, 388);
            button1.Name = "button1";
            button1.Size = new Size(103, 36);
            button1.TabIndex = 6;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(140, 354);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 7;
            label1.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(386, 354);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 8;
            label2.Text = "label2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(641, 354);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 9;
            label3.Text = "label3";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(panel13);
            Controls.Add(panel11);
            Controls.Add(panel12);
            Name = "Form1";
            Text = "Form1";
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private Panel panel12;
        private Panel panel11;
        private RadioButton radioButton5;
        private RadioButton radioButton6;
        private RadioButton radioButton7;
        private RadioButton radioButton8;
        private Panel panel13;
        private RadioButton radioButton9;
        private RadioButton radioButton10;
        private RadioButton radioButton11;
        private RadioButton radioButton12;
        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}